# 负向因子反转可行性验�?�?完整试验方案

> **author:** 墨衡 (deepseek-reasoner)
> **version:** v1.2
> **version_schema:** v2
> **version_content:** 3
> **version_status:** 已修�?[准予执行]
> **关联 signal_defined�?* pending
>
> **试验编号�?* EXP-2026-INVFAC-002
> **设计人：** 墨衡
> **设计日期�?* 2026-05-25
>
> **引用确认记录�?*
> - R001 讨论会：`R001_discussion.md`�?026-05-25T16:30~16:32�?> - R001 问题定义草案：`R001_draft.md`（✅ Owner签，2026-05-25T16:39�?> - 状态划分方法确认：`state_method_confirmation.md`（墨涵确认，2026-05-25T16:40�?
---

## 〇、R001 问题定义（执行前必须通过�?
> �?**R001共识确认**�?026-05-25T16:39，Owner 裁定�?> 引用讨论会记录：`R001_discussion.md`，共识要点已在�?.5通过条件核查表中全部确认�?
### 0.1 现状描述

基于墨枢 Phase 1 IC/IR 检验报告（12只标的，1210个交易日），38个注册因子中�?8 个因子呈�?*持续负向 IC**，IR 均低�?0，正值比均低�?50%�?
| 因子�?| 层级 | Mean IC | IR | IC正值比 |
|:------|:---:|:------:|:--:|:-------:|
| l_vol_rsi_std | L1 | -0.0129 | -0.0397 | 48.10% |
| l_vol_kurt | L1 | -0.0083 | -0.0259 | 48.10% |
| l_vol_vwap_dev | L1 | -0.0086 | -0.0258 | 48.84% |
| l_vol_smart_money | L1 | -0.0066 | -0.0210 | 49.50% |
| l_str_kdj_k | L1 | -0.0029 | -0.0082 | 47.77% |
| l_trd_adx | L1 | -0.0005 | -0.0014 | 49.01% |
| l_trd_strength | L1 | -0.0005 | -0.0014 | 49.01% |
| l_trd_composite_score | L1 | -0.0002 | -0.0005 | 49.26% |

| 项目 | 内容 |
|:----|:----|
| 标的 | 12只（A50成分股） |
| 时间�?| 2021-01-01 ~ 2025-12-31 |
| 关键数据 | 8个因�?IC 为负（IR<0, 正值比<50%）但 L3-L1 多空收益差分值达 -0.0492~-0.0502 |
| 数据来源 | market_data.db（唯一权威源）|
| 复权方式 | qfq 前复权（强制�?|
| adj_base_date | 2026-05-01（初定，最终见 §2.2�?|

### 0.2 不解决的后果

1. **信息损失**�?个负IC因子占注册因�?21%，若其中部分含有�?*反向信号**（均值回归），丢弃等于丢失信号源  
2. **组合维度盲区**：覆盖成交量波动、量价偏离、资金聪明度、趋势强度等独立维度，丢弃后对应维度空白  
3. **状态切换风�?*：负IC因子可能在特定市场状态（震荡/恐慌期）转正，全样本检验掩盖这种状态依赖。若存在相位性反转因子，每漏掉一个，在对应的市场状态区间内策略将失去一个有效信号维度，预期收益损失 0.5-1.5%/状态周�? 

### 0.3 根因分析

- **第一层（直接原因�?*：IC/IR 全样本静态检验框架不存在负向因子的分阶段/分市场状态检验机�? 
- **第二层（间接原因�?*：框架未区分两种不同负IC模式�? 
  模式A（真正噪声）——IC 随机波动，无显著性，�?l_trd_composite_score (IC�?)  
  模式B（相位性反转）——IC 分阶段显著正负交替，�?TrendQuality �?01857�?5d IC=-0.083 �?m转正 +0.058  
- **第三层（系统性原因）**：因子度量体系缺少时间非平稳性检验维度。当前全样本静态均值假设与市场状态切换的现实矛盾  
  > 已追至可解释极限

### 0.4 问题陈述

**墨枢**�?*因子IC/IR全样本静态检�?*场景下，�?*框架未区分负IC因子�?真正噪声"�?相位性反转信�?两种模式**，导�?*8个（21%）注册因子被系统搁置，IC正值比全部低于50%，但分层回测L3-L1多空收益率差值达-0.0492�?0.0502，提示存在结构性偏差而非纯噪�?*�?
### 0.5 通过条件核查

| 条件 | 负责�?| 状�?| 验收人签�?日期 |
|:----|:-----|:---:|:-------------:|
| 现状有数据支�?| 墨衡（提案人�?| �?| Owner/2026-05-25 |
| 影响范围和紧急性已评估 | 墨衡（提案人�?| �?| Owner/2026-05-25 |
| 根因至少到第三层 | 团队讨论 | �?| Owner/2026-05-25 |
| 问题陈述全员认可 | 墨涵确认 | �?| 墨涵/2026-05-25 |
| 写入任务文档 | 墨涵 | �?| 墨涵/2026-05-25 |

**R001 共识锁定项（不可变更）：**

| 项目 | 决策 |
|:----|:-----|
| 首批因子 | **TrendQuality + l_vol_rsi_std + l_str_kdj_k**（三机制验证�?|
| 切片方式 | **市场状态优�?*（状态内嵌多持有�?5/10/20日） |
| 状态划�?| **滚动波动率分位数**（高: top 20%, �? bottom 30%, �? 其余50%�?|
| 反转标准 | IC符号转换 + bootstrap显著�?p<0.05) + 稳定性检�?|
| 数据来源 | market_data.db（已统一�?|
| 复权方式 | qfq 前复权（强制�?|

---

## 一、试验背景与核心假设

### 1.1 背景

本试验来源于墨枢 Phase 1 IC/IR 检验报告中识别�?**8个负IC因子**。全样本静态检验中这些因子 IR<0、IC正值比<50%，但分层回测 L3-L1 多空收益差分值显著不为零�?0.0492~-0.0502），提示存在**非对称结构性偏�?*�?
�?Owner 裁定，首批选取三个跨维度因子验证反转可行性：
- **TrendQuality**（结构�?趋势质量维度�?- **l_vol_rsi_std**（量�?成交量RSI维度�?- **l_str_kdj_k**（技术指�?KDJ维度�?
三者机制独立，若反转验证通过则泛化能力显著高于单维度因子验证�?
### 1.2 核心假设（可证伪�?
- **H0（原假设�?*：在全部市场状态（�?�?低波动）下，对首批三个负IC因子做符号反转处理后，分层回�?IC 正值比�?�?50%、IR �?0.05，或反转信号�?bootstrap 检验中不显著（p �?0.05），说明负IC为真正噪声而非相位性反转信号�?- **H1（备择假设）**：在**特定市场状�?*下（主要是低波动/高波动尾部），至少一个因子的符号反转能产生显著的 IC 正值比 > 50%、IR > 0.05，且 bootstrap p < 0.05，说明该因子存在状态依赖的相位性反转模式�?
### 1.3 因子体系归属

| 因子�?| 层级 | 说明 |
|:----|:---:|:----|
| TrendQuality | L2 相对化量 | 趋势质量指标，基于价格动量的相对化构�?|
| l_vol_rsi_std | L1 绝对�?| 成交�?RSI 的滚动标准差，高频量能发散度 |
| l_str_kdj_k | L1 绝对�?| KDJ 指标 K 值，超买超卖区域的极端值反�?|

> **注意�?* 以上因子名均已确认存在于 `methods.db` 因子注册表中，未注册时回测引擎将拒绝执行�?
---

## 二、数据与标的定义

### 2.1 标的池（Universe�?
| 项目 | 内容 |
|:----|:----|
| 标的列表 | �?A50 成分股为基础�?2只标的，�?Phase 1 报告一致） |
| 排除标准 | 停牌�?>20%、ST 股票、上市未�?�?|
| free_float 口径 | 东财口径（系统唯一标准口径�?|
| free_float_source 字段�?| eastmoney |
| **free_float 下限** | **�?0.5** |
| **复权质量校验** | **adj_factor 异常跳变检验（详见 2.3�?* |

### 2.2 数据窗口

| 阶段 | 开�?| 结束 | adj_base_date | 说明 |
|:---|:---:|:---:|:------------:|:----|
| 暖机期（Warm-up�?| 2021-01-01 | 2021-12-31 | 2026-05-01 | 至少为最长因子窗口（20日）�?2 倍，不参与回�?|
| 样本内（In-Sample�?| 2022-01-01 | 2024-06-30 | 2026-05-01 | 用于参数扫描+IC/IR主检�?|
| 样本外（Out-of-Sample�?| 2024-07-01 | 2025-12-31 | 2026-05-01 | 盲测，锁定参数后运行 |

**停复牌运行时处理规则�?*
1. **持有期遇停牌**：停牌期间信号保留，复牌后首个交易日以复牌价执行买入/卖出
2. **复牌价格处理**：以复牌当日开盘价执行（如涨停/跌停则延迟至可交易）
3. **长期停牌标记**：停牌超�?20 个交易日 �?标记为异常停牌（`exception_suspension = 1`），排除因子计算
4. **信号边界敏感说明**：复牌首日的跳空缺口可能影响因子值，需在试验报告中注明

**暖机期受限标记：**
- 若标的上市日期晚于暖机期开始日�?�?该标的标�?暖机期受限（`warmup_limited = true`�?
- 受限标的在回测报告中单独列示其起始时�?
### 2.3 数据质量前置检�?
此项为硬性要求，执行回测前必须通过。使用预置脚�?`data_qc_check.py`（路径：`C:\Users\17699\mozhi_platform\scripts\qc\data_qc_check.py`，版本锁定引用。禁止使�?assert 替代脚本执行）�?
**检查内容：**
- adj_factor NULL 检查（硬阻断）
- adj_factor 异常跳变 >50% 检查（硬阻断）
- Buy & Hold 验证（信息校验）

```bash
python data_qc_check.py --ts_code {ts_code} --start 2021-01-01 --end 2025-12-31
```

> **验收规则�?* 脚本输出�?`validation_check` 记录必须存在�?`backtest_run` 关联�?`validation_check` 表中�?
---

## 三、计算细�?
### 3.1 因子计算

#### 3.1.1 TrendQuality

趋势质量因子，反映价格趋势的稳定性与一致性�?
```python
def calc_trend_quality(high, low, close, period=20):
    """
    计算趋势质量指标�?    逻辑：衡量当前价格处于趋势中的位置稳定性�?    """
    # 计算平均真实波幅作为归一化基础
    tr = np.maximum(high - low, 
                    np.abs(high - np.roll(close, 1)),
                    np.abs(low - np.roll(close, 1)))
    atr = rolling_mean(tr, period)
    
    # 价格位置偏移度量
    price_pos = (close - rolling_min(low, period)) / (rolling_max(high, period) - rolling_min(low, period) + 1e-10)
    
    # 趋势质量 = 价格位置的偏离度与ATR的比�?    tq = (price_pos - 0.5) / (atr / close + 1e-10)
    
    return tq
```

#### 3.1.2 l_vol_rsi_std

成交�?RSI 的滚动标准差，衡量成交量动能发散程度�?
```python
def calc_vol_rsi_std(volume, rsi_period=14, std_period=20):
    """
    计算成交�?RSI 的滚动标准差�?    逻辑：成交量 RSI �?std 反映量能发散/收敛状态�?    """
    # 成交量变化率
    vol_change = volume.diff()
    gain = vol_change.clip(lower=0)
    loss = (-vol_change).clip(lower=0)
    
    avg_gain = rolling_mean(gain, rsi_period)
    avg_loss = rolling_mean(loss, rsi_period)
    
    rs = avg_gain / (avg_loss + 1e-10)
    vol_rsi = 100 - (100 / (1 + rs))
    
    # 滚动标准�?    vol_rsi_std = rolling_std(vol_rsi, std_period)
    return vol_rsi_std
```

#### 3.1.3 l_str_kdj_k

KDJ 指标�?K 值，经典超买超卖指标�?
```python
def calc_kdj_k(high, low, close, period=9, k_smooth=3):
    """
    计算 KDJ K 值�?    """
    low_min = rolling_min(low, period)
    high_max = rolling_max(high, period)
    
    rsv = (close - low_min) / (high_max - low_min + 1e-10) * 100
    
    # K = 2/3 * prev_K + 1/3 * RSV
    k = ema(rsv, k_smooth)
    return k
```

#### 3.1.4 符号反转规则

对原始负IC因子值做**符号取反**处理�?```python
factor_reversed = -1.0 * factor_original
```

> **注意�?* 反转仅在**市场状态切分后的子�?*内部进行，不是全样本统一反转。具体反转后检验流程见 §5�?
### 3.2 市场状态分类（滚动波动率分位数�?
#### 3.2.1 状态划分实�?
```python
def classify_market_state(close, percentile_high=0.80, percentile_low=0.30, window=20, warmup_vol=None):
    """
    滚动波动率分位数状态分类�?    
    参数�?    - percentile_high: 高波动分位数阈值（默认 0.80 �?top 20%�?    - percentile_low: 低波动分位数阈值（默认 0.30 �?bottom 30%�?    - window: 滚动窗口（默�?20 交易日）
    - warmup_vol: 暖机期（2021-01~2021-12）波动率序列；若提供，阈值仅基于该序列计�?    
    返回：state 序列�?=高波�? 1=中波�? 0=低波动）
    """
    returns = close.pct_change()
    rolling_vol = rolling_std(returns, window) * np.sqrt(252)
    
    # 阈值计算：优先使用暖机期数据锁定阈值，避免前视偏差
    vol_series = rolling_vol.dropna()
    if warmup_vol is not None:
        high_threshold = np.percentile(warmup_vol, percentile_high * 100)
        low_threshold = np.percentile(warmup_vol, percentile_low * 100)
    else:
        high_threshold = np.percentile(vol_series, percentile_high * 100)
        low_threshold = np.percentile(vol_series, percentile_low * 100)
    
    state = np.zeros_like(rolling_vol, dtype=int)
    state[rolling_vol >= high_threshold] = 2  # 高波�?    state[(rolling_vol < high_threshold) & (rolling_vol >= low_threshold)] = 1  # 中波�?    state[rolling_vol < low_threshold] = 0  # 低波�?    
    return state, high_threshold, low_threshold
```

#### 3.2.2 默认分位数参数（§4 灵敏度检验的基准值）

| 状�?| 分位数范�?| 比例 | 标记 |
|:----|:---------:|:----:|:---:|
| 高波动（panic�?| top 20% (�?0%分位) | ~20% 交易�?| `state=2` |
| 中波动（consolidation�?| 30%~80%分位 | ~50% 交易�?| `state=1` |
| 低波动（trend�?| bottom 30% (�?0%分位) | ~30% 交易�?| `state=0` |

### 3.3 Bootstrap 置换检�?
对每个因�?× 每个市场状态子�?× 每个持有期的组合执行 bootstrap 检验：

```python
def bootstrap_ic_test(factor_values, forward_returns, n_bootstrap=10000, alpha=0.05):
    """
    Bootstrap 置换检验判�?IC 均值是否显著偏�?0�?    
    参数�?    - factor_values: 因子值序�?    - forward_returns: 前向收益序列（与因子值等长）
    - n_bootstrap: 置换次数
    - alpha: 显著性水�?    
    返回：{'p_value': float, 'significant': bool, 'ci_lower': float, 'ci_upper': float}
    """
    ic_mean = spearman_correlation(factor_values, forward_returns)
    n = len(factor_values)
    
    # 置换检验：对因子值随机重排后重新计算 IC（打破因�?收益配对关系�?    bootstrap_means = []
    for _ in range(n_bootstrap):
        shuffled_factor = np.random.permutation(factor_values)
        boot_ic = spearman_correlation(shuffled_factor, forward_returns)
        bootstrap_means.append(boot_ic)
    
    bootstrap_means = np.array(bootstrap_means)
    p_value = np.mean(np.abs(bootstrap_means) >= np.abs(ic_mean))
    
    # 百分位置信区�?    ci_lower = np.percentile(bootstrap_means, alpha/2 * 100)
    ci_upper = np.percentile(bootstrap_means, (1 - alpha/2) * 100)
    
    return {
        'p_value': p_value,
        'significant': p_value < alpha,
        'ci_lower': ci_lower,
        'ci_upper': ci_upper
    }
```

### 3.4 多持有期计算

每个因子�?*每个市场状态子�?*内分别计�?5日�?0日�?0日持有期�?IC 序列�?
```python
def compute_forward_ic(factor_series, forward_returns, periods=[5, 10, 20]):
    """
    计算多个持有期的前向 IC�?    
    返回：{period: ic_series} 字典
    """
    ic_by_period = {}
    for period in periods:
        fwd_ret = forward_returns.shift(-period)  # 前向收益
        ic = rolling_spearman(factor_series, fwd_ret, window=period)
        ic_by_period[period] = ic
    return ic_by_period
```

### 3.5 稳定性检查（三层验证链）

详见 §5 检验与验证�?
### 3.6 随机种子

```python
random_seed = 42  # 固定种子，用�?bootstrap 置换检验的可复�?```

---

## 四、参数敏感性分�?
### 4.1 分位数阈值敏感性分�?
对市场状态划分的核心参数——波动率分位数阈值——做网格灵敏度扫描：

| 参数 | 基准�?| 扫描范围 | 步长 |
|:---|:-----:|:-------:|:---:|
| high 分位�?| 0.80 | [0.75, 0.80, 0.85] | 0.05 |
| low 分位�?| 0.30 | [0.25, 0.30, 0.35] | 0.05 |

**组合矩阵�?×3=9组）�?*

```
   low\high  0.75   0.80   0.85
   0.25      [  ]   [  ]   [  ]
   0.30      [  ]   [★] 基准 [  ]
   0.35      [  ]   [  ]   [  ]
```

**分析指标（每组计算）�?*
1. 各状态下 IC 均值及正值比
2. 反转标准通过率（三层检验通过/不通过�?3. 状态边界样本的 IC 稳定性（边界±5%内交易日 vs 非边界）

**稳健性判定规则：**
- **通过**：≥7/9 组的反转检验结果一致（全通过或全不通过�?- **边界敏感（需标注�?*�?-6 组结果翻转（阈值选择敏感�?- **不稳定（不建议采用）**�?3 组一致（分位数方法不适用，建议换 HMM�?
### 4.2 持有期敏感性分�?
| 参数 | 基准�?| 扫描范围 |
|:---|:-----:|:-------:|
| 持有�?| 5/10/20 �?| 同上（内嵌因子） |

持有期不做额外扫描，作为市场状态切分的内嵌维度。敏感性体现在：同一因子同一状态下，不同持有期的反转检验是否一致�?
### 4.3 HMM 替代检验（稳健性补充）

�?§4.1 敏感性分析判定为"不稳�?，使�?HMM（隐马尔可夫模型）作为状态划分的替代方案进行稳健性检验（仅检验用，不替代主结论）。HMM 参数�?- 状态数�?（低/�?高波动，保持与分位数法一致）
- 观测序列：每日收益率
- 协方差类型：对角

---

## 五、检验与验证：三层反转确认标�?
### 5.1 第一层：IC 符号转换检�?
**触发条件**：因子在全样本中 IC 均�?< 0（负向因子资格确认）�?
**检验方法：**
1. 按市场状态切分（�?�?低波动）
2. 在各状态子集内，对因子值做符号反转：`factor_reversed = -1 * factor`
3. 计算反转后各状态的 IC 序列（含 5/10/20 日持有期�?4. 判断条件�?   - **主条�?*：反转后 IC 均�?> 0（符号转换成功）
   - **辅条�?*：反转后 IC 正值比 > 50%（方向性一致确认）

**通过条件**：至少一个状�?× 一个持有期组合满足主条�?辅条件�?
### 5.2 第二层：Bootstrap 显著性检�?
**检验方法：**
1. 对第一层通过的所有（状态×持有期）组合执�?bootstrap 置换检验（n=10,000�?2. 零假设：IC 均�?= 0（即反转信号无统计意义）
3. 双尾检验，显著性水�?α = 0.05

**多重比较校正**：采�?Benjamini-Hochberg FDR 控制，q = 0.05。对 27 组检验的 p 值统一排序后应�?BH 过程，控�?FDR �?5% 以下�?
**通过条件**：p 值经 BH 校正�?q < 0.05（即 adjusted p < 0.05），拒绝零假设，反转信号统计显著

### 5.3 第三层：稳定性检�?
**检验方法：**
1. **时间切片稳定�?*：将样本内数据按时间分为 4 等份，每份独立计算反转后 IC 均�?   - 通过条件：≥3/4 切片 IC 符号一致（方向稳定�?2. **Rolling 稳定�?*：使�?6 个月滚动窗口计算反转�?IC
   - 通过条件：滚�?IC 窗口正负翻转�?< 30%（不频繁摇摆�?3. **标的交叉稳定�?*：统计各标的的反转后 IC 方向一致�?   - 通过条件：≥8/12 标的 IC 方向一�?4. **样本外稳定�?*（OOS 数据上重复以上检验）
   - 通过条件：OOS 方向�?IS 一致（IC 符号一致，不再要求 p 值）

**综合判定**：三层稳定性条�?*至少满足 3/4** 视为通过稳定性检查�?
### 5.4 反转标准综合判定�?
| 条件 | 方法 | 阈�?| 权重 |
|:---|:----|:----|:---:|
| L1: IC 符号转正 | 符号反转�?IC 均�?0 | >0 | 必须 |
| L1: 正值比 | 反转�?IC 正值比 | >50% | 必须 |
| L2: 统计显著�?| Bootstrap p 值（FDR BH 校正�?| q<0.05（BH adjusted p<0.05�?| 必须 |
| L3: 时间切片稳定 | 4 等份切片方向一�?| �?/4 | 综合 |
| L3: Rolling 稳定 | 滚动 IC 翻转�?| <30% | 综合 |
| L3: 标的交叉稳定 | 标的 IC 方向一致�?| �?/12 | 综合 |
| L3: 样本外稳�?| OOS 方向�?IS 一�?| 方向一致（不要�?p 值） | 综合 |

**最终判定：**
- **反转信号确认**：L1 + L2 全部通过，且 L3 综合�?/4
- **反转信号存疑**：L1 + L2 通过，但 L3 < 3/4（需标注"弱稳定�?�?- **反转信号拒绝**：L1 �?L2 任意一项不通过

---

## 六、预期产�?
### 6.1 判定标准

| 结果 | 条件 | 后续动作 |
|:---|:----|:--------|
| **反转信号确认**（H1成立�?| 任一因子在任一（状态×持有期）组合通过三层检�?| 1. 确认反转后的信号进入 signal_defined 候选池<br>2. 触发后续信号组合试验<br>3. 记录该状态依赖参数至 knowledge.db |
| **反转信号存疑**（部分验证） | L1+L2 通过�?L3 弱，或仅特定标的成立 | 1. 标记�?橙色"（低置信度候选）<br>2. 扩展标的池后再验�?br>3. 不进�?signal_defined |
| **反转信号拒绝**（H0成立�?| 三个因子在所有（状态×持有期）组合均不通过 | 1. 进入正式拒绝归档（归档至 failure_knowledge�?br>2. �?全样本负IC=噪声"写入 knowledge.db<br>3. 不触�?signal_defined |

### 6.2 预期产出文件

| 产出 | 路径 | 说明 |
|:---|:----|:----|
| IC/IR 检验报告（分状态） | `reports/EXP-2026-INVFAC-002/ic_ir_{状态}.csv` | 每状态×持有期�?IC/IR 汇�?|
| Bootstrap 显著性报�?| `reports/EXP-2026-INVFAC-002/bootstrap_{factor}.csv` | 各条件组合的自举检�?p �?|
| 稳定性诊断报�?| `reports/EXP-2026-INVFAC-002/stability_{factor}.csv` | 三层稳定性检查结�?|
| 敏感性分析报�?| `reports/EXP-2026-INVFAC-002/sensitivity.csv` | 分位数阈值的灵敏度矩�?|
| 参数字段锁定记录 | `params_snapshot` �?| 最终选择的参数组合及理由 |
| 完整试验报告 | `signals/tasks/EXP-2026-INVFAC-002_report.md` | 汇总以上所有结�?|

### 6.3 反转模式矩阵（预期输出）

每个因子生成以下矩阵格式的结果摘要：

```
因子: TrendQuality
┌─────────────────────────────────────────────�?�?状态\持有�?   5�?      10�?     20�?    �?├─────────────────────────────────────────────�?�?高波�?panic)  [IC][sig][sta]                �?�?中波�?consol)                               �?�?低波�?trend)                                �?└─────────────────────────────────────────────�?各单元格：IC方向 | bootstrap p | 稳定性标�?```

---

## 七、风险与限制

### 7.1 方法论风�?
| 风险 | 等级 | 说明 | 缓解措施 |
|:----|:---:|:----|:--------|
| **分位数硬边界效应** | �?| 滚动波动率分位数的边界阈值（top 20%/bottom 30%）是硬切割，边界附近的交易日可能归属不稳定（小样本扰动导致状态跳变） | §4.1 敏感性分析覆盖边界�?pct；边界交易日单独标注分析 |
| **状态内样本量不�?* | �?| 高波动状态约 20% 交易日（~240�?5年），再�?10�?20日持有期后子窗口更小，统计检验功效下�?| Bootstrap 对小样本有较好的鲁棒性；标注 <200 交易日的不稳定区�?|
| **时滞效应** | �?| 滚动波动率计算本身的时滞——当日波动率状态基于历�?20 日窗口，真实市场状态切换可能已发生 | 在设计报告中标注时滞窗口；HMM替代检验可提供更多时序信息 |
| **多重比较问题** | �?| 3因子 × 3状�?× 3持有�?= 27 个检验组合，多重比较可能产生 I 类错误膨胀 | Bootstrap + 事后多重比较校正（FDR Benjamini-Hochberg，q=0.05�?|
| **前视偏差** | �?| 全样本分位数阈值基于整个样本期计算，在暖机期结束后的回测窗口内相当于使用了未来信息 | 阈值在暖机期结束后一次性锁定，不使用回测窗口内的滚动阈值；替代方案：滚动期分位数（仅在回测到的时间点往前看）作为稳健性补�?|
| **OOS 数据不足** | �?| 样本外窗口（2024-07~2025-12）约 18 个月，对高波动状态的覆盖可能不完�?| 在报告中标注 OOS 各状态覆盖天数；如覆盖不足则标注"OOS状态不平衡" |

### 7.2 数据风险

| 风险 | 等级 | 说明 |
|:----|:---:|:----|
| adj_factor 复权质量 | �?| 部分标的在特定区间可能存在复权因子跳变，影响 qfq 价格序列的连续�?|
| 非交易日本地噪声 | �?| 节假日及 A 股特有停牌规则可能导致长时间数据空缺 |
| 涨跌停板效应 | �?| 极端行情下涨跌停限制可能影响 IC 计算的准确性，尤其是在高波动状�?|

### 7.3 试验局限�?
1. **标的池限�?*�?2�?A50 成分股，结论向全 A 股市场的泛化需要额外验�?2. **状态定义单一依赖**：当前仅使用波动率一维指标定义市场状态，不排除其他状态划分方式（HMM、趋势强度、成交量等）产生不同结论
3. **三因子代表性边�?*：首批三因子不能代表全部 8 个负IC因子；通过/否决结果严格限定在此三因子范围内
4. **因子反转的根本逻辑未验�?*：即使反转信号成立，本试验只确认了统计层面的反转显著性，未验证反转的驱动逻辑（均值回�?vs 信息释放 vs 流动性驱动）

---

## 附录 A：文件清�?
| 文件 | 路径 | 说明 |
|:---|:----|:----|
| 本方�?| `docs/07_research/EXP-2026-INVFAC-002/design.md` | **[当前文件]** 完整试验方案 |
| R001 讨论会记�?| `docs/07_research/EXP-2026-INVFAC-002/R001_discussion.md` | Owner 裁定记录 |
| R001 问题定义草案 | `docs/07_research/EXP-2026-INVFAC-002/R001_draft.md` | §0 问题定义详细�?|
| 状态划分方法确�?| `docs/07_research/EXP-2026-INVFAC-002/state_method_confirmation.md` | 墨涵确认的状态划分参�?|

---

## 附录 B：快速填写检查清�?
**R001 问题定义�?*
- [x] 现状有数据支撑（非猜测）
- [x] 根因追到第三层（已标�?已追至可解释极限"�?- [x] 问题陈述包含"对象+偏差+可观测指�?
- [x] 墨涵已确认写入任务文�?
**数据层：**
- [x] 数据源为 market_data.db（非 analysis.db�?- [x] 复权方式�?qfq
- [ ] adj_factor �?NULL（回测前验证�?- [ ] adj_factor 无异常跳变（回测前验证）
- [x] free_float 口径为东�?- [ ] free_float �?0.5（回测前筛选）
- [ ] 标的上市已满 2 年（回测前筛选）

**代码层：**
- [ ] version_tag 已记录（当前：未使用版本管理—工作副本，未提交）
- [ ] P2 自洽性已验证（回测触发）
- [x] 随机种子已固定（seed=42�?- [x] 使用预置脚本 `data_qc_check.py`（非内联 assert�?
**回测层：**
- [x] 暖机期已排除�?021-01~2021-12 不参与回测）
- [x] A 股硬约束已启�?- [x] 样本�?样本外严格分�?- [x] 停复牌处理规则已应用
- [ ] `trade_log` 中已包含 `exec_time` 字段（回测时验证�?
---

## 附录 C：预置脚本清�?
| 脚本路径 | 用�?| 调用时机 |
|:-------|:----|:--------|
| `scripts/qc/data_qc_check.py` | 数据质量前置检�?| Step3 |
| `scripts/utils/mark_abandoned.py` | 废弃结果标记 | 发现数据污染�?|
| `scripts/archive/archive_failure.py` | 失败案例归档 | H0 成立�?|
| `scripts/utils/calc_period_trading_days.py` | 计算区间交易日数 | Step5 数据库写入时 |
| `scripts/knowledge/search_failure_knowledge.py` | 检索历史失败案�?| Step1 知识库自查时 |
| `scripts/layer_q/run_layer_q_audit.py` | Layer Q 审计模块 | Step7 |
| `scripts/writeback/finalize_exp.py` | 试验最终化：两库写�?状态标�?| 试验完成�?|
